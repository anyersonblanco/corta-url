<?php

namespace App\Http\Controllers;

use App\Models\ProjectAccess;
use App\Services\GoogleSearchConsoleClient;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class GoogleOAuthController extends Controller
{
    /**
     * Inicia el flow OAuth: redirige a Google con state cifrado que lleva
     * el project_access_id para recuperarlo en el callback.
     */
    public function start(Request $request)
    {
        $paId = $request->integer('project_access_id');
        if (!$paId) {
            return response('Falta query param project_access_id. Usar el boton "Conectar Google" desde un ProjectAccess en el panel.', 400);
        }

        $pa = ProjectAccess::find($paId);
        if (!$pa) {
            return response("ProjectAccess #$paId no encontrado", 404);
        }

        // State firmado por Laravel Crypt: incluye id + nonce timestamp (mitiga replay)
        $state = Crypt::encryptString(json_encode([
            'pa' => $pa->id,
            't'  => now()->timestamp,
            'n'  => bin2hex(random_bytes(8)),
        ]));

        return redirect()->away(
            GoogleSearchConsoleClient::authorizationUrl($state)
        );
    }

    /**
     * Callback Google: exchange code → tokens, persiste encrypted al ProjectAccess.
     */
    public function callback(Request $request)
    {
        if ($error = $request->query('error')) {
            return response("Google denegó: $error", 400);
        }

        $code = $request->query('code');
        $stateRaw = $request->query('state');
        if (!$code || !$stateRaw) {
            return response('Parámetros code/state faltantes', 400);
        }

        try {
            $state = json_decode(Crypt::decryptString($stateRaw), true);
        } catch (\Throwable $e) {
            return response('State inválido (decrypt fallo)', 400);
        }

        if (empty($state['pa']) || empty($state['t'])) {
            return response('State malformado', 400);
        }
        // Anti-replay: state expira a los 15 min
        if (now()->timestamp - (int) $state['t'] > 900) {
            return response('State expirado, reiniciá la conexión', 400);
        }

        $pa = ProjectAccess::find((int) $state['pa']);
        if (!$pa) {
            return response('ProjectAccess no encontrado', 404);
        }

        try {
            $tokens = GoogleSearchConsoleClient::exchangeAuthCode($code);
        } catch (\Throwable $e) {
            return response('Token exchange fallo: ' . $e->getMessage(), 500);
        }

        $pa->update([
            'gsc_access_token'     => $tokens['access_token'] ?? null,
            'gsc_refresh_token'    => $tokens['refresh_token'] ?? null,
            'gsc_token_expires_at' => now()->addSeconds((int) ($tokens['expires_in'] ?? 3600)),
            'gsc_last_synced_at'   => now(),
        ]);

        return redirect('/admin/project-accesses/' . $pa->id)
            ->with('success', 'Google Search Console conectado para ' . $pa->nombre);
    }
}
