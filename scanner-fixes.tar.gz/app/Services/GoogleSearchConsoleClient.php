<?php

namespace App\Services;

use App\Models\ProjectAccess;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Cliente Google Search Console API (Webmasters v3 + Search Console v1).
 * Auto-refresh del access_token cuando expira usando refresh_token.
 *
 * Docs:
 * - https://developers.google.com/webmaster-tools/v1/searchanalytics/query
 * - https://developers.google.com/webmaster-tools/v1/urlInspection.index/inspect
 * - https://developers.google.com/identity/protocols/oauth2/web-server
 */
class GoogleSearchConsoleClient
{
    // Scope que matchea con lo declarado en Google Auth Platform del proyecto Webtilia.
    // El scanner solo LEE (urlInspection + searchAnalytics + listSitemaps),
    // pero se declaro el scope completo "webmasters" en consola para evitar
    // mismatch en el OAuth consent. Funciona igual; el read-only es subset.
    public const SCOPE = 'https://www.googleapis.com/auth/webmasters';
    public const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
    public const TOKEN_URL = 'https://oauth2.googleapis.com/token';

    private const BASE_WM   = 'https://www.googleapis.com/webmasters/v3/';
    private const BASE_SC   = 'https://searchconsole.googleapis.com/v1/';
    private const TIMEOUT_S = 30;
    // Refresca el token cuando le quedan menos de este margen de vida
    private const REFRESH_MARGIN_S = 60;

    public function __construct(
        private readonly ProjectAccess $pa,
    ) {}

    /**
     * URL de autorizacion OAuth para iniciar el flow.
     * El $state lleva project_access_id firmado/cifrado.
     */
    public static function authorizationUrl(string $state, ?string $redirectUri = null): string
    {
        $params = [
            'client_id'     => config('services.google.client_id'),
            'redirect_uri'  => $redirectUri ?? config('services.google.redirect_uri'),
            'response_type' => 'code',
            'scope'         => self::SCOPE,
            'access_type'   => 'offline',  // necesario para obtener refresh_token
            'prompt'        => 'consent',  // fuerza re-autorizacion -> garantiza refresh_token
            'state'         => $state,
            'include_granted_scopes' => 'true',
        ];
        return self::AUTH_URL . '?' . http_build_query($params);
    }

    /**
     * Cambia un authorization_code por access_token + refresh_token.
     * Devuelve array con keys: access_token, refresh_token, expires_in, scope, token_type.
     */
    public static function exchangeAuthCode(string $code, ?string $redirectUri = null): array
    {
        $r = Http::asForm()->timeout(self::TIMEOUT_S)->post(self::TOKEN_URL, [
            'code'          => $code,
            'client_id'     => config('services.google.client_id'),
            'client_secret' => config('services.google.client_secret'),
            'redirect_uri'  => $redirectUri ?? config('services.google.redirect_uri'),
            'grant_type'    => 'authorization_code',
        ]);
        if (!$r->successful()) {
            throw new \RuntimeException('Google token exchange fallo: ' . $r->status() . ' ' . $r->body());
        }
        return $r->json();
    }

    /**
     * Lista properties verificadas en GSC (sites) accesibles por estos tokens.
     */
    public function listSites(): array
    {
        $r = $this->req('GET', self::BASE_WM . 'sites');
        return $r->json('siteEntry', []);
    }

    /**
     * Inspeccion de una URL especifica: indexabilidad real, cobertura, robots, ultimo crawl.
     */
    public function inspectUrl(string $inspectionUrl, ?string $siteUrl = null): array
    {
        $r = $this->req('POST', self::BASE_SC . 'urlInspection/index:inspect', [], [
            'inspectionUrl' => $inspectionUrl,
            'siteUrl'       => $siteUrl ?? $this->pa->gsc_property_url,
            'languageCode'  => 'es-PE',
        ]);
        return $r->json('inspectionResult', []);
    }

    /**
     * Metricas SEO: clicks/impressions/CTR/position agregadas o por dimension.
     *
     * @param  array  $dimensions  ['query'|'page'|'country'|'device'|'date'|'searchAppearance']
     */
    public function searchAnalytics(
        string $startDate,
        string $endDate,
        array $dimensions = [],
        int $rowLimit = 10,
        ?string $siteUrl = null,
    ): array {
        $site = rawurlencode($siteUrl ?? $this->pa->gsc_property_url);
        $r = $this->req('POST', self::BASE_WM . "sites/{$site}/searchAnalytics/query", [], [
            'startDate'  => $startDate,
            'endDate'    => $endDate,
            'dimensions' => $dimensions,
            'rowLimit'   => $rowLimit,
        ]);
        return $r->json();
    }

    /**
     * Sitemaps registrados para la property.
     */
    public function listSitemaps(?string $siteUrl = null): array
    {
        $site = rawurlencode($siteUrl ?? $this->pa->gsc_property_url);
        $r = $this->req('GET', self::BASE_WM . "sites/{$site}/sitemaps");
        return $r->json('sitemap', []);
    }

    /**
     * Refresca el access_token cuando esta vencido o por vencer.
     * Persiste los nuevos valores en ProjectAccess.
     */
    public function refrescarTokenSiHaceFalta(): void
    {
        $exp = $this->pa->gsc_token_expires_at;
        if ($exp && now()->lt($exp->copy()->subSeconds(self::REFRESH_MARGIN_S))) {
            return;  // todavia valido
        }
        if (empty($this->pa->gsc_refresh_token)) {
            throw new \RuntimeException('No hay refresh_token disponible — reconectar GSC');
        }

        $r = Http::asForm()->timeout(self::TIMEOUT_S)->post(self::TOKEN_URL, [
            'client_id'     => config('services.google.client_id'),
            'client_secret' => config('services.google.client_secret'),
            'refresh_token' => $this->pa->gsc_refresh_token,
            'grant_type'    => 'refresh_token',
        ]);
        if (!$r->successful()) {
            Log::warning('GSC refresh fallo: ' . $r->status() . ' ' . $r->body());
            throw new \RuntimeException('GSC refresh fallo: ' . $r->status());
        }
        $data = $r->json();
        $this->pa->update([
            'gsc_access_token' => $data['access_token'],
            'gsc_token_expires_at' => now()->addSeconds((int) ($data['expires_in'] ?? 3600)),
            // Google a veces NO devuelve nuevo refresh_token; preservar el viejo
            'gsc_refresh_token' => $data['refresh_token'] ?? $this->pa->gsc_refresh_token,
        ]);
        // Refrescar la instancia
        $this->pa->refresh();
    }

    private function req(string $method, string $url, array $query = [], ?array $json = null): Response
    {
        $this->refrescarTokenSiHaceFalta();
        $req = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pa->gsc_access_token,
            'Accept' => 'application/json',
        ])->timeout(self::TIMEOUT_S);
        if ($json !== null) {
            $req = $req->asJson();
        }
        return match ($method) {
            'GET'    => $req->get($url, $query),
            'POST'   => $req->post($url . (empty($query) ? '' : '?' . http_build_query($query)), $json ?? []),
            'DELETE' => $req->delete($url, $query),
        };
    }
}
